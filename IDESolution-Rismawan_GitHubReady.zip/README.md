# IDESolution-Rismawan

ID3 Decision Tree Java implementation - GitHub-ready repository prepared for submission.

**Author:** Rismawan Maulana Sidiq (NIM: 1202210240)  
**Institution:** Telkom University  
**Dosen Pengampu:** Agus Gandara

## Struktur
```
IDESolution-Rismawan/
├── src/                # Java source code
├── data/               # Example CSV datasets
├── README.md
├── .gitignore
└── build/              # (empty) for compiled classes if needed
```

## Cara Compile & Jalankan (Linux / macOS / Windows with bash)

1. Masuk folder src dan compile:
```bash
cd src
javac *.java
```

2. Jalankan single dataset (contoh Play.csv):
```bash
java DriverTree ../data/Play.csv 3
```

3. Jalankan semua dataset (menggunakan MainTest):
```bash
java MainTest 3
```

Parameter `3` adalah maxDepth (pre-pruning). Jika tidak ingin membatasi depth, omit angka tersebut.

## Catatan
- Parser CSV sederhana: kompatibel untuk file CSV tanpa koma di dalam field; untuk dataset kompleks, disarankan gunakan OpenCSV.
- Jika ingin integrasi CI/CD ke GitHub Actions atau dokumentasi tambahan, saya bisa bantu set up.
