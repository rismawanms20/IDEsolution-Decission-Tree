/*
Author: Rismawan Maulana Sidiq
NIM: 1202210240
Telkom University
Dosen Pengampu: Agus Gandara
Project: ID3 Decision Tree (Java)
Repository: IDESolution-Rismawan
*/

import java.io.FileNotFoundException;

/**
 * MainTest - convenience runner to execute DriverTree on all datasets.
 * Usage: java MainTest [maxDepth]
 */
public class MainTest {
    public static void main(String[] args) throws FileNotFoundException {
        int maxDepth = Integer.MAX_VALUE;
        if (args.length >= 1) {
            try { maxDepth = Integer.parseInt(args[0]); } catch (Exception e) { }
        }
        String[] datasets = { "data/Play.csv", "data/play7.csv", "data/play8.csv" };
        for (String ds : datasets) {
            System.out.println(\"\\n===== Running on: \" + ds + \" =====\");
            DriverTree.main(new String[] { ds, (maxDepth==Integer.MAX_VALUE?\"\":String.valueOf(maxDepth)) });
        }
    }
}
