/*
Author: Rismawan Maulana Sidiq
NIM: 1202210240
Telkom University
Dosen Pengampu: Agus Gandara
Project: ID3 Decision Tree (Java)
Repository: IDESolution-Rismawan
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 * Simple ID3 implementation (categorical data).
 * Enhancements:
 * - Reads CSV from relative path.
 * - Supports MAX_DEPTH pre-pruning to avoid overfitting.
 * - Contains helpful comments for maintainability.
 */
public class ID3 {
    public static final boolean DEV_MODE = true;
    public List<ArrayList<String>> rawdata = new ArrayList<ArrayList<String>>();	
    public int MAX_DEPTH = Integer.MAX_VALUE; // allow setting pre-pruning depth

    public List<ArrayList<String>> loadCSV(String filepath) {
        try {
            Scanner sc = new Scanner(new File(filepath));
            List<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.length()==0) continue;
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"); // simple CSV split
                ArrayList<String> row = new ArrayList<String>();
                for (String p : parts) row.add(p.replaceAll("\"",""));
                data.add(row);
            }
            sc.close();
            return data;
        } catch (FileNotFoundException e) {
            System.err.println("CSV file not found: " + filepath);
            return null;
        }
    }

    // Utility: print raw data
    public void printArrayList(List<ArrayList<String>> arr) {
        System.out.println("\n--- Data Preview ---");
        for (ArrayList<String> r : arr) {
            for (String c : r) System.out.print(c + "\t");
            System.out.println();
        }
    }

    // Entry point for building tree. Now accepts current depth for pre-pruning.
    public Tree runID3(List<ArrayList<String>> data, Node parent, int currentDepth) {
        Tree root = new Tree();
        // if reached MAX_DEPTH, create leaf node with majority class
        if (currentDepth >= MAX_DEPTH) {
            String maj = majorityClass(data);
            root.setRoot(new Node(NodeType.LEAF, maj));
            return root;
        }
        // header assumed in first row
        List<String> header = data.get(0);
        if (data.size() <= 1) {
            root.setRoot(new Node(NodeType.LEAF, majorityClass(data)));
            return root;
        }
        // choose attribute with highest info gain (skipping last column as target)
        int bestCol = -1;
        double bestGain = -1;
        for (int c = 0; c < header.size()-1; c++) {
            double gain = informationGain(data, c);
            if (gain > bestGain) { bestGain = gain; bestCol = c; }
        }
        if (bestCol == -1) {
            root.setRoot(new Node(NodeType.LEAF, majorityClass(data)));
            return root;
        }
        // create decision node
        Node node = new Node(NodeType.NODE, header.get(bestCol));
        root.setRoot(node);
        // split by distinct values
        Set<String> vals = uniqueValues(data, bestCol);
        for (String v : vals) {
            List<ArrayList<String>> subset = filterByValueAndRemoveColumn(data, bestCol, v);
            if (subset.size() == 1) {
                Node leaf = new Node(NodeType.LEAF, majorityClass(subset));
                node.addChild(leaf);
            } else {
                Tree childTree = runID3(subset, node, currentDepth+1);
                node.addChild(childTree.getRoot());
            }
        }
        return root;
    }

    // Helper: compute majority class from last column
    public String majorityClass(List<ArrayList<String>> data) {
        java.util.Map<String,Integer> counts = new java.util.HashMap<String,Integer>();
        for (int i=1;i<data.size();i++) {
            List<String> row = data.get(i);
            String cls = row.get(row.size()-1);
            counts.put(cls, counts.getOrDefault(cls,0)+1);
        }
        String best=null; int bestc=-1;
        for (java.util.Map.Entry<String,Integer> e : counts.entrySet()) {
            if (e.getValue() > bestc) { bestc = e.getValue(); best = e.getKey(); }
        }
        return best;
    }

    // Compute information gain for a column (simple entropy calculation)
    public double informationGain(List<ArrayList<String>> data, int col) {
        double totalEntropy = entropy(data);
        java.util.Map<String, List<ArrayList<String>>> groups = new java.util.HashMap<>();
        for (int i=1;i<data.size();i++) {
            String v = data.get(i).get(col);
            groups.computeIfAbsent(v, k-> new ArrayList<ArrayList<String>>()).add(data.get(i));
        }
        double weighted = 0.0;
        for (java.util.Map.Entry<String, List<ArrayList<String>>> e : groups.entrySet()) {
            double p = (double)e.getValue().size() / (data.size()-1);
            weighted += p * entropyList(e.getValue());
        }
        return totalEntropy - weighted;
    }

    // Entropy over last column for full dataset (skip header)
    public double entropy(List<ArrayList<String>> data) {
        java.util.Map<String,Integer> counts = new java.util.HashMap<String,Integer>();
        for (int i=1;i<data.size();i++) {
            String cls = data.get(i).get(data.get(i).size()-1);
            counts.put(cls, counts.getOrDefault(cls,0)+1);
        }
        double ent = 0.0;
        int total = data.size()-1;
        for (Integer v : counts.values()) {
            double p = (double)v / total;
            ent -= p * (Math.log(p)/Math.log(2));
        }
        return ent;
    }

    // entropy for subset
    public double entropyList(List<ArrayList<String>> subset) {
        java.util.Map<String,Integer> counts = new java.util.HashMap<String,Integer>();
        for (List<String> r : subset) {
            String cls = r.get(r.size()-1);
            counts.put(cls, counts.getOrDefault(cls,0)+1);
        }
        double ent = 0.0;
        int total = subset.size();
        for (Integer v : counts.values()) {
            double p = (double)v / total;
            ent -= p * (Math.log(p)/Math.log(2));
        }
        return ent;
    }

    // Unique values in a column (skipping header)
    public Set<String> uniqueValues(List<ArrayList<String>> data, int col) {
        Set<String> s = new HashSet<String>();
        for (int i=1;i<data.size();i++) s.add(data.get(i).get(col));
        return s;
    }

    // Filters rows matching val at column col and removes that column from subset (keeps header updated)
    public List<ArrayList<String>> filterByValueAndRemoveColumn(List<ArrayList<String>> data, int col, String val) {
        List<ArrayList<String>> out = new ArrayList<ArrayList<String>>();
        // new header without column col
        ArrayList<String> newHeader = new ArrayList<String>();
        for (int c=0;c<data.get(0).size();c++) if (c!=col) newHeader.add(data.get(0).get(c));
        out.add(newHeader);
        for (int i=1;i<data.size();i++) {
            if (data.get(i).get(col).equals(val)) {
                ArrayList<String> row = new ArrayList<String>();
                for (int c=0;c<data.get(i).size();c++) if (c!=col) row.add(data.get(i).get(c));
                out.add(row);
            }
        }
        return out;
    }
}
