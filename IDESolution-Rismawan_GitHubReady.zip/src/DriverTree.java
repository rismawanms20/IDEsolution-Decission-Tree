/*
Author: Rismawan Maulana Sidiq
NIM: 1202210240
Telkom University
Dosen Pengampu: Agus Gandara
Project: ID3 Decision Tree (Java)
Repository: IDESolution-Rismawan
*/

import java.io.FileNotFoundException;

/**
 * Driver class for ID3 demonstration.
 * Usage: java DriverTree [path/to/csv] [maxDepth]
 * If no args provided, will look for 'data/Play.csv' in project root.
 */
public class DriverTree {
    public static void main(String[] args) throws FileNotFoundException {
        String csvPath = "data/Play.csv";
        int maxDepth = Integer.MAX_VALUE;
        if (args.length >= 1) csvPath = args[0];
        if (args.length >= 2) {
            try {
                maxDepth = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid maxDepth, using unlimited.");
            }
        }
        System.out.println("Loading CSV: " + csvPath + "  maxDepth=" + (maxDepth==Integer.MAX_VALUE?"unlimited":maxDepth));
        ID3 id3 = new ID3();
        id3.MAX_DEPTH = maxDepth;
        id3.rawdata = id3.loadCSV(csvPath);
        if (id3.rawdata == null || id3.rawdata.size()==0) {
            System.err.println("No data loaded. Exiting."); return;
        }
        id3.printArrayList(id3.rawdata);
        // Build tree
        Tree t = id3.runID3(id3.rawdata, null, 0);
        System.out.println("\n--- Decision Tree ---");
        t.printTree();
    }
}
