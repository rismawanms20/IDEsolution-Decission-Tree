/*
Author: Rismawan Maulana Sidiq
NIM: 1202210240
Telkom University
Dosen Pengampu: Agus Gandara
Project: ID3 Decision Tree (Java)
Repository: IDESolution-Rismawan
*/

/ ** Tree wrapper to host root node and printing **/
public class Tree {
    private Node root;
    public void setRoot(Node r) { this.root = r; }
    public Node getRoot() { return root; }
    // Simple print: DFS
    public void printTree() {
        printNode(root, 0);
    }
    private void printNode(Node n, int depth) {
        if (n==null) return;
        for (int i=0;i<depth;i++) System.out.print("  ");
        System.out.println(n.toString());
        for (Node c : n.getChildren()) printNode(c, depth+1);
    }
}
