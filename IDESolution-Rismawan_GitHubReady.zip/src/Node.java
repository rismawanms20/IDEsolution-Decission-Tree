/*
Author: Rismawan Maulana Sidiq
NIM: 1202210240
Telkom University
Dosen Pengampu: Agus Gandara
Project: ID3 Decision Tree (Java)
Repository: IDESolution-Rismawan
*/

import java.util.ArrayList;
import java.util.List;

/**
 * Node for decision tree.
 */
public class Node {
    private NodeType type;
    private String value; // attribute name (for NODE) or class (for LEAF)
    private List<Node> children = new ArrayList<Node>();

    public Node(NodeType type, String value) {
        this.type = type; this.value = value;
    }
    public NodeType getType() { return type; }
    public String getValue() { return value; }
    public void addChild(Node n) { children.add(n); }
    public List<Node> getChildren() { return children; }
    public String toString() {
        return (type==NodeType.LEAF?"LEAF":"NODE") + ":" + value;
    }
}
